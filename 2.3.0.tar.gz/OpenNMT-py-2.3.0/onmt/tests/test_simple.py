import onmt


def test_load():
    onmt
    pass
