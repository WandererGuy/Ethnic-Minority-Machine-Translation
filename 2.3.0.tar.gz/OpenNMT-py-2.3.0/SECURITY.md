# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.2.x   | :white_check_mark: |
| 1.2.x   | :x:                |

## Reporting a Vulnerability

Please open an issue, or contact one of the maintainers via [gitter](https://gitter.im/OpenNMT/OpenNMT-py).
